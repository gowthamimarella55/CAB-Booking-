import { useMemo, useState } from 'react';
import {
  supabase, CAB_OPTIONS, CabType, DISCOUNT_CODES, POPULAR_PLACES, REFRESHMENTS_CATALOG,
  calcFare, estimateDistance, randomDriver,
} from '../lib/supabase';
import { useAuth } from '../lib/AuthContext';
import {
  Car, CarFront, CarTaxiFront, Bus, Crown, MapPin, Navigation, Search,
  Clock, Users, Tag, Gift, Sparkles, ArrowRight, Check, X, Star,
} from 'lucide-react';

const CAB_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Car, CarFront, CarTaxiFront, Bus, Crown,
};

interface Props {
  onBooked: (bookingId: string) => void;
}

export default function BookRide({ onBooked }: Props) {
  const { user, profile } = useAuth();
  const [pickup, setPickup] = useState('');
  const [dropoff, setDropoff] = useState('');
  const [cabType, setCabType] = useState<CabType>('economy');
  const [discountCode, setDiscountCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<{ code: string; pct: number } | null>(null);
  const [discountError, setDiscountError] = useState<string | null>(null);
  const [refreshments, setRefreshments] = useState<string[]>([]);
  const [donation, setDonation] = useState(0);
  const [searching, setSearching] = useState(false);
  const [booking, setBooking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const distance = useMemo(() => {
    if (!pickup.trim() || !dropoff.trim()) return 0;
    return estimateDistance(pickup, dropoff);
  }, [pickup, dropoff]);

  const duration = useMemo(() => Math.max(5, Math.round(distance * 2.4)), [distance]);

  const baseFare = useMemo(() => (distance > 0 ? calcFare(cabType, distance) : 0), [cabType, distance]);
  const refreshmentCost = useMemo(
    () => REFRESHMENTS_CATALOG.filter((r) => refreshments.includes(r.id)).reduce((s, r) => s + r.price, 0),
    [refreshments]
  );
  const discountAmount = appliedDiscount ? Math.round(baseFare * appliedDiscount.pct) : 0;
  const total = Math.max(0, baseFare - discountAmount) + refreshmentCost + donation;

  function applyDiscount() {
    setDiscountError(null);
    const code = discountCode.trim().toUpperCase();
    if (!code) return;
    const pct = DISCOUNT_CODES[code];
    if (!pct) {
      setDiscountError('That code isn’t valid.');
      setAppliedDiscount(null);
      return;
    }
    setAppliedDiscount({ code, pct });
  }

  function toggleRefresh(id: string) {
    setRefreshments((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]));
  }

  async function book() {
    if (!pickup.trim() || !dropoff.trim()) {
      setError('Enter pickup and drop-off locations.');
      return;
    }
    setError(null);
    setSearching(true);
    setTimeout(async () => {
      setSearching(false);
      setBooking(true);
      const driver = randomDriver();
      const { data, error: insError } = await supabase
        .from('bookings')
        .insert({
          pickup: pickup.trim(),
          dropoff: dropoff.trim(),
          cab_type: cabType,
          fare: total,
          distance_km: distance,
          duration_min: duration,
          status: 'enroute',
          eta_min: parseInt(CAB_OPTIONS.find((c) => c.id === cabType)!.eta, 10),
          donation,
          refreshments,
          discount_code: appliedDiscount?.code ?? null,
          discount_amount: discountAmount,
          payment_method: 'Cash',
          ...driver,
        })
        .select('id')
        .single();
      setBooking(false);
      if (insError || !data) {
        setError('Could not create your booking. Please try again.');
        return;
      }
      onBooked(data.id);
    }, 2200);
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 pb-10">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Hi {profile?.full_name?.split(' ')[0] ?? 'there'}, where to?
        </h1>
        <p className="text-slate-400 mt-1">Book a cab in seconds and track your driver live.</p>
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 sm:p-6">
            <div className="space-y-3">
              <LocationRow
                icon={<div className="w-3 h-3 rounded-full bg-emerald-400" />}
                placeholder="Pickup location"
                value={pickup}
                onChange={setPickup}
                suggestions={POPULAR_PLACES}
              />
              <div className="ml-4 border-l-2 border-dashed border-slate-700 h-4" />
              <LocationRow
                icon={<MapPin className="w-4 h-4 text-rose-400" />}
                placeholder="Where to?"
                value={dropoff}
                onChange={setDropoff}
                suggestions={POPULAR_PLACES}
              />
            </div>
            {(pickup || dropoff) && (
              <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-400">
                <span className="inline-flex items-center gap-1 bg-slate-800/70 px-2.5 py-1 rounded-full">
                  <Navigation className="w-3 h-3" /> {distance.toFixed(1)} km
                </span>
                <span className="inline-flex items-center gap-1 bg-slate-800/70 px-2.5 py-1 rounded-full">
                  <Clock className="w-3 h-3" /> {duration} min
                </span>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3 px-1">Choose your ride</h3>
            <div className="space-y-2.5">
              {CAB_OPTIONS.map((opt) => {
                const Icon = CAB_ICONS[opt.icon];
                const fare = distance > 0 ? calcFare(opt.id, distance) : null;
                const active = cabType === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => setCabType(opt.id)}
                    className={`w-full text-left rounded-xl border p-4 flex items-center gap-4 transition-all ${
                      active
                        ? 'bg-emerald-500/10 border-emerald-500 ring-1 ring-emerald-500/40'
                        : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${active ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300'}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{opt.name}</span>
                        <span className="text-xs text-slate-400 inline-flex items-center gap-1">
                          <Users className="w-3 h-3" /> {opt.capacity}
                        </span>
                      </div>
                      <p className="text-sm text-slate-400 truncate">{opt.desc}</p>
                    </div>
                    <div className="text-right">
                      {fare !== null ? (
                        <div className="text-lg font-bold text-white">${fare}</div>
                      ) : (
                        <div className="text-sm text-slate-500">—</div>
                      )}
                      <div className="text-xs text-slate-400 inline-flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {opt.eta}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5">
            <h3 className="text-sm font-semibold text-slate-300 mb-3 inline-flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" /> Extras
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {REFRESHMENTS_CATALOG.map((r) => {
                const active = refreshments.includes(r.id);
                return (
                  <button
                    key={r.id}
                    onClick={() => toggleRefresh(r.id)}
                    className={`rounded-lg p-3 text-left border transition-all ${
                      active ? 'bg-emerald-500/15 border-emerald-500' : 'bg-slate-800/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-white">{r.name}</span>
                      {active && <Check className="w-4 h-4 text-emerald-400" />}
                    </div>
                    <div className="text-xs text-slate-400">${r.price}</div>
                  </button>
                );
              })}
            </div>

            <div className="mt-4">
              <div className="text-sm font-medium text-slate-300 mb-2 inline-flex items-center gap-2">
                <Gift className="w-4 h-4 text-emerald-400" /> Add a donation
              </div>
              <div className="flex gap-2">
                {[0, 10, 25, 50].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setDonation(amt)}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                      donation === amt ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {amt === 0 ? 'None' : `$${amt}`}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5">
            <h3 className="text-sm font-semibold text-slate-300 mb-3 inline-flex items-center gap-2">
              <Tag className="w-4 h-4 text-emerald-400" /> Discount code
            </h3>
            <div className="flex gap-2">
              <input
                value={discountCode}
                onChange={(e) => setDiscountCode(e.target.value)}
                placeholder="Try UCAB10"
                className="input-field flex-1"
              />
              <button
                onClick={applyDiscount}
                className="px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
              >
                Apply
              </button>
            </div>
            {discountError && <p className="text-xs text-rose-400 mt-2">{discountError}</p>}
            {appliedDiscount && (
              <div className="mt-2 flex items-center justify-between text-sm bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-3 py-2">
                <span className="text-emerald-300 inline-flex items-center gap-2">
                  <Check className="w-4 h-4" /> {appliedDiscount.code} ({Math.round(appliedDiscount.pct * 100)}% off)
                </span>
                <button onClick={() => { setAppliedDiscount(null); setDiscountCode(''); }}>
                  <X className="w-4 h-4 text-slate-400 hover:text-white" />
                </button>
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-gradient-to-br from-emerald-500/10 to-slate-900/40 border border-slate-800 p-5">
            <h3 className="text-sm font-semibold text-slate-300 mb-3">Fare summary</h3>
            <Row label="Ride fare" value={`$${baseFare}`} />
            {discountAmount > 0 && <Row label="Discount" value={`-$${discountAmount}`} accent />}
            {refreshmentCost > 0 && <Row label="Refreshments" value={`$${refreshmentCost}`} />}
            {donation > 0 && <Row label="Donation" value={`$${donation}`} />}
            <div className="border-t border-slate-700 mt-3 pt-3 flex items-center justify-between">
              <span className="text-slate-300 font-medium">Total</span>
              <span className="text-2xl font-bold text-white">${total}</span>
            </div>
            <button
              onClick={book}
              disabled={searching || booking || !pickup.trim() || !dropoff.trim()}
              className="mt-4 w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 disabled:cursor-not-allowed text-slate-950 font-semibold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              {searching ? (
                <><span className="spinner" /> Finding your driver…</>
              ) : booking ? (
                <><span className="spinner" /> Confirming…</>
              ) : (
                <>Book now <ArrowRight className="w-4 h-4" /></>
              )}
            </button>
            {error && <p className="text-sm text-rose-400 mt-3 text-center">{error}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

function LocationRow({
  icon, placeholder, value, onChange, suggestions,
}: {
  icon: React.ReactNode; placeholder: string; value: string;
  onChange: (v: string) => void; suggestions: string[];
}) {
  const [focused, setFocused] = useState(false);
  const matches = focused
    ? suggestions.filter((s) => s.toLowerCase().includes(value.toLowerCase()) && s.toLowerCase() !== value.toLowerCase()).slice(0, 4)
    : [];
  return (
    <div className="relative">
      <div className="flex items-center gap-3 bg-slate-800/40 border border-slate-700 rounded-xl px-3 py-3 focus-within:border-emerald-500 transition-colors">
        <div className="text-slate-400">{icon}</div>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 150)}
          placeholder={placeholder}
          className="flex-1 bg-transparent outline-none text-white placeholder-slate-500"
        />
        {value && (
          <button onClick={() => onChange('')} className="text-slate-500 hover:text-slate-300">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      {matches.length > 0 && (
        <div className="absolute z-20 mt-1 w-full bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-xl">
          {matches.map((s) => (
            <button
              key={s}
              onMouseDown={() => { onChange(s); setFocused(false); }}
              className="w-full text-left px-4 py-2.5 text-sm text-slate-200 hover:bg-slate-700 flex items-center gap-2"
            >
              <Search className="w-3.5 h-3.5 text-slate-500" /> {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Row({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1 text-sm">
      <span className="text-slate-400">{label}</span>
      <span className={accent ? 'text-emerald-400 font-medium' : 'text-slate-200'}>{value}</span>
    </div>
  );
}
