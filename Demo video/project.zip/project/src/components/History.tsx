import { useEffect, useState } from 'react';
import { supabase, Booking } from '../lib/supabase';
import { MapPin, Navigation, Clock, Star, Gift, Sparkles, Tag } from 'lucide-react';

export default function History() {
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [filter, setFilter] = useState<'all' | 'completed' | 'cancelled'>('all');

  useEffect(() => {
    supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => setBookings((data as Booking[]) ?? []));
  }, []);

  const filtered = (bookings ?? []).filter((b) =>
    filter === 'all' ? true : b.status === filter
  );

  const totalSpent = (bookings ?? []).filter((b) => b.status === 'completed').reduce((s, b) => s + Number(b.fare), 0);
  const totalTrips = (bookings ?? []).filter((b) => b.status === 'completed').length;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 pb-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Your trips</h1>
      <p className="text-slate-400 mt-1">Review past rides, fares, and extras.</p>

      <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-3">
        <StatCard label="Total trips" value={String(totalTrips)} />
        <StatCard label="Total spent" value={`$${totalSpent}`} />
        <StatCard label="Avg fare" value={totalTrips ? `$${Math.round(totalSpent / totalTrips)}` : '$0'} />
      </div>

      <div className="mt-6 flex gap-2">
        {(['all', 'completed', 'cancelled'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3.5 py-1.5 rounded-full text-sm font-medium capitalize transition-colors ${
              filter === f ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {bookings === null ? (
        <div className="text-center text-slate-400 py-16"><span className="spinner mx-auto mb-3" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-3">
            <Navigation className="w-6 h-6 text-slate-500" />
          </div>
          <p className="text-slate-400">No trips here yet.</p>
          <p className="text-slate-500 text-sm mt-1">Book a ride to see it appear in your history.</p>
        </div>
      ) : (
        <div className="mt-5 space-y-3">
          {filtered.map((b) => (
            <div key={b.id} className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 sm:p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <StatusBadge status={b.status} />
                    <span className="text-xs text-slate-500">
                      {new Date(b.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center gap-2 text-sm">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-slate-200 truncate">{b.pickup}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-sm">
                    <MapPin className="w-2.5 h-2.5 text-rose-400" />
                    <span className="text-slate-200 truncate">{b.dropoff}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xl font-bold text-white">${b.fare}</div>
                  <div className="text-xs text-slate-500 capitalize">{b.cab_type}</div>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-400">
                <Chip icon={<Navigation className="w-3 h-3" />}>{Number(b.distance_km).toFixed(1)} km</Chip>
                <Chip icon={<Clock className="w-3 h-3" />}>{b.duration_min} min</Chip>
                {b.driver_name && (
                  <Chip icon={<Star className="w-3 h-3 text-amber-400 fill-amber-400" />}>
                    {b.driver_name.split(' ')[0]} • {b.vehicle_plate}
                  </Chip>
                )}
                {b.discount_amount > 0 && (
                  <Chip icon={<Tag className="w-3 h-3 text-emerald-400" />}>
                    {b.discount_code} -${b.discount_amount}
                  </Chip>
                )}
                {b.donation > 0 && (
                  <Chip icon={<Gift className="w-3 h-3 text-emerald-400" />}>Donation ${b.donation}</Chip>
                )}
                {b.refreshments && b.refreshments.length > 0 && (
                  <Chip icon={<Sparkles className="w-3 h-3 text-emerald-400" />}>
                    {b.refreshments.length} refreshment{b.refreshments.length > 1 ? 's' : ''}
                  </Chip>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4">
      <div className="text-2xl font-bold text-white">{value}</div>
      <div className="text-sm text-slate-400">{label}</div>
    </div>
  );
}

function Chip({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 bg-slate-800/60 px-2.5 py-1 rounded-full">
      {icon} {children}
    </span>
  );
}

function StatusBadge({ status }: { status: Booking['status'] }) {
  const map: Record<Booking['status'], { label: string; cls: string }> = {
    searching: { label: 'Searching', cls: 'bg-amber-500/15 text-amber-300' },
    enroute: { label: 'En route', cls: 'bg-sky-500/15 text-sky-300' },
    arrived: { label: 'Arrived', cls: 'bg-indigo-500/15 text-indigo-300' },
    inprogress: { label: 'In progress', cls: 'bg-emerald-500/15 text-emerald-300' },
    completed: { label: 'Completed', cls: 'bg-emerald-500/15 text-emerald-300' },
    cancelled: { label: 'Cancelled', cls: 'bg-rose-500/15 text-rose-300' },
  };
  const s = map[status];
  return <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${s.cls}`}>{s.label}</span>;
}
