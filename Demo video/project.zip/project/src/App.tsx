import { useState } from 'react';
import { AuthProvider, useAuth } from './lib/AuthContext';
import AuthScreen from './components/AuthScreen';
import BookRide from './components/BookRide';
import RideTracking from './components/RideTracking';
import History from './components/History';
import PaymentMethods from './components/PaymentMethods';
import Profile from './components/Profile';
import { Car, Home, CreditCard, User, Clock } from 'lucide-react';

type Tab = 'book' | 'history' | 'payments' | 'profile';

function Shell() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState<Tab>('book');
  const [activeRide, setActiveRide] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <span className="spinner" />
      </div>
    );
  }
  if (!user) return <AuthScreen />;

  if (activeRide) {
    return (
      <div className="min-h-screen bg-slate-950">
        <RideTracking bookingId={activeRide} onDone={() => { setActiveRide(null); setTab('history'); }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="sticky top-0 z-30 backdrop-blur bg-slate-950/80 border-b border-slate-800">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <Car className="w-5 h-5 text-slate-950" />
            </div>
            <span className="font-bold text-lg tracking-tight">Ucab</span>
          </div>
          <nav className="hidden sm:flex items-center gap-1">
            <NavBtn active={tab === 'book'} onClick={() => setTab('book')} icon={<Home className="w-4 h-4" />}>Book</NavBtn>
            <NavBtn active={tab === 'history'} onClick={() => setTab('history')} icon={<Clock className="w-4 h-4" />}>Trips</NavBtn>
            <NavBtn active={tab === 'payments'} onClick={() => setTab('payments')} icon={<CreditCard className="w-4 h-4" />}>Payments</NavBtn>
            <NavBtn active={tab === 'profile'} onClick={() => setTab('profile')} icon={<User className="w-4 h-4" />}>Account</NavBtn>
          </nav>
        </div>
      </header>

      <main className="flex-1 pt-6">
        {tab === 'book' && <BookRide onBooked={(id) => setActiveRide(id)} />}
        {tab === 'history' && <History />}
        {tab === 'payments' && <PaymentMethods />}
        {tab === 'profile' && <Profile />}
      </main>

      <nav className="sm:hidden sticky bottom-0 z-30 bg-slate-950/95 backdrop-blur border-t border-slate-800 grid grid-cols-4">
        <MobileNav active={tab === 'book'} onClick={() => setTab('book')} icon={<Home className="w-5 h-5" />} label="Book" />
        <MobileNav active={tab === 'history'} onClick={() => setTab('history')} icon={<Clock className="w-5 h-5" />} label="Trips" />
        <MobileNav active={tab === 'payments'} onClick={() => setTab('payments')} icon={<CreditCard className="w-5 h-5" />} label="Pay" />
        <MobileNav active={tab === 'profile'} onClick={() => setTab('profile')} icon={<User className="w-5 h-5" />} label="Me" />
      </nav>
    </div>
  );
}

function NavBtn({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-1.5 rounded-lg text-sm font-medium inline-flex items-center gap-1.5 transition-colors ${
        active ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
      }`}
    >
      {icon} {children}
    </button>
  );
}

function MobileNav({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className={`py-2.5 flex flex-col items-center gap-0.5 text-xs ${active ? 'text-emerald-400' : 'text-slate-500'}`}>
      {icon}
      <span>{label}</span>
    </button>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
