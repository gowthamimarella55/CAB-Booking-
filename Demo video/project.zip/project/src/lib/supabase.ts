import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(url, anonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type CabType = 'economy' | 'comfort' | 'premium' | 'xl' | 'lux';

export interface Profile {
  id: string;
  full_name: string;
  phone: string;
  avatar_url: string | null;
  created_at: string;
}

export interface PaymentMethod {
  id: string;
  user_id: string;
  nickname: string;
  brand: string;
  last4: string;
  is_default: boolean;
  created_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  pickup: string;
  dropoff: string;
  cab_type: CabType;
  fare: number;
  distance_km: number;
  duration_min: number;
  status: 'searching' | 'enroute' | 'arrived' | 'inprogress' | 'completed' | 'cancelled';
  driver_name: string | null;
  driver_rating: number | null;
  vehicle_plate: string | null;
  eta_min: number | null;
  donation: number;
  refreshments: string[];
  discount_code: string | null;
  discount_amount: number;
  payment_method: string | null;
  created_at: string;
  completed_at: string | null;
}

export const CAB_OPTIONS: {
  id: CabType;
  name: string;
  desc: string;
  baseFare: number;
  perKm: number;
  capacity: string;
  eta: string;
  icon: string;
}[] = [
  { id: 'economy', name: 'Economy', desc: 'Affordable everyday rides', baseFare: 25, perKm: 12, capacity: '4 seats', eta: '3 min', icon: 'Car' },
  { id: 'comfort', name: 'Comfort', desc: 'Newer cars, extra legroom', baseFare: 40, perKm: 16, capacity: '4 seats', eta: '4 min', icon: 'CarFront' },
  { id: 'premium', name: 'Premium', desc: 'Top-rated drivers, sedans', baseFare: 60, perKm: 22, capacity: '4 seats', eta: '5 min', icon: 'CarTaxiFront' },
  { id: 'xl', name: 'XL', desc: 'Vans for groups up to 6', baseFare: 55, perKm: 20, capacity: '6 seats', eta: '6 min', icon: 'Bus' },
  { id: 'lux', name: 'Lux', desc: 'High-end black cars', baseFare: 90, perKm: 35, capacity: '4 seats', eta: '7 min', icon: 'Crown' },
];

export const REFRESHMENTS_CATALOG = [
  { id: 'water', name: 'Bottled Water', price: 30 },
  { id: 'soda', name: 'Soft Drink', price: 40 },
  { id: 'snack', name: 'Snack Pack', price: 55 },
  { id: 'coffee', name: 'Coffee', price: 60 },
];

export const DISCOUNT_CODES: Record<string, number> = {
  UCAB10: 0.1,
  NEWRIDER: 0.15,
  SUMMER25: 0.25,
};

export const POPULAR_PLACES = [
  'Central Station',
  'Riverside Mall',
  'City Hospital',
  'Tech Park',
  'International Airport',
  'University Campus',
  'Harbor View Hotel',
  'Old Town Square',
  'Stadium',
  'Convention Center',
];

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

export function estimateDistance(pickup: string, dropoff: string): number {
  const seed = hash(pickup + dropoff);
  return Math.round((3 + (seed % 22) + Math.random() * 2) * 10) / 10;
}

export function calcFare(cab: CabType, distance: number): number {
  const opt = CAB_OPTIONS.find((c) => c.id === cab)!;
  return Math.round(opt.baseFare + opt.perKm * distance);
}

export const DRIVER_NAMES = [
  'Michael Chen', 'Sarah Johnson', 'David Martinez', 'Priya Patel',
  'James Wilson', 'Aisha Khan', 'Robert Lee', 'Elena Rodriguez',
  'Daniel Brown', 'Fatima Ali',
];

export const VEHICLE_PLATES = [
  'UCB-1042', 'UCB-2381', 'UCB-5567', 'UCB-8901', 'UCB-3344',
  'UCB-7721', 'UCB-6190', 'UCB-4488', 'UCB-9923', 'UCB-1207',
];

export function randomDriver() {
  const i = Math.floor(Math.random() * DRIVER_NAMES.length);
  return {
    driver_name: DRIVER_NAMES[i],
    vehicle_plate: VEHICLE_PLATES[i],
    driver_rating: Math.round((4.6 + Math.random() * 0.4) * 10) / 10,
  };
}
