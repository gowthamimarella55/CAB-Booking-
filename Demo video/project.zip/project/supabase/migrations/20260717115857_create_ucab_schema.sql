/*
# Ucab cab booking app schema

1. New Tables
- `profiles` — user profile (name, phone, avatar_url). One row per auth user.
- `bookings` — a ride booking: pickup, dropoff, cab type, fare, distance, duration, status, optional donation/refreshments/discount, driver name/plate/rating.
- `payment_methods` — saved payment methods (card nickname, last4, brand) per user.

2. Security
- Enable RLS on all tables.
- Owner-scoped CRUD: each authenticated user can only access rows they own.
- `profiles` keyed by `id = auth.uid()`.
- `bookings` and `payment_methods` keyed by `user_id` with DEFAULT auth.uid().
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  pickup text NOT NULL,
  dropoff text NOT NULL,
  cab_type text NOT NULL,
  fare numeric NOT NULL DEFAULT 0,
  distance_km numeric NOT NULL DEFAULT 0,
  duration_min numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'searching',
  driver_name text,
  driver_rating numeric,
  vehicle_plate text,
  eta_min numeric,
  donation numeric NOT NULL DEFAULT 0,
  refreshments jsonb NOT NULL DEFAULT '[]'::jsonb,
  discount_code text,
  discount_amount numeric NOT NULL DEFAULT 0,
  payment_method text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_bookings" ON bookings;
CREATE POLICY "select_own_bookings" ON bookings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_bookings" ON bookings;
CREATE POLICY "insert_own_bookings" ON bookings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_bookings" ON bookings;
CREATE POLICY "update_own_bookings" ON bookings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_bookings" ON bookings;
CREATE POLICY "delete_own_bookings" ON bookings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS bookings_user_created_idx ON bookings (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  nickname text NOT NULL,
  brand text NOT NULL DEFAULT 'Visa',
  last4 text NOT NULL,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_payment_methods" ON payment_methods;
CREATE POLICY "select_own_payment_methods" ON payment_methods FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_payment_methods" ON payment_methods;
CREATE POLICY "insert_own_payment_methods" ON payment_methods FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_payment_methods" ON payment_methods;
CREATE POLICY "update_own_payment_methods" ON payment_methods FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_payment_methods" ON payment_methods;
CREATE POLICY "delete_own_payment_methods" ON payment_methods FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
