import { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { supabase } from '../lib/supabase';
import { User as UserIcon, Phone, Mail, LogOut, Save, Check } from 'lucide-react';

export default function Profile() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    await supabase.from('profiles').update({ full_name: fullName, phone }).eq('id', user!.id);
    await refreshProfile();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 pb-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Account</h1>
      <p className="text-slate-400 mt-1">Manage your profile and sign out.</p>

      <div className="mt-6 rounded-2xl bg-gradient-to-br from-emerald-500/15 to-slate-900/40 border border-slate-800 p-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-slate-950 text-xl font-bold">
            {(profile?.full_name || user?.email || '?').slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-white truncate">{profile?.full_name || 'Ucab rider'}</div>
            <div className="text-sm text-slate-400 truncate">{user?.email}</div>
          </div>
        </div>
      </div>

      <form onSubmit={save} className="mt-5 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-4">
        <div>
          <label className="text-sm text-slate-300 font-medium inline-flex items-center gap-2"><UserIcon className="w-4 h-4" /> Full name</label>
          <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="input-field mt-1.5" />
        </div>
        <div>
          <label className="text-sm text-slate-300 font-medium inline-flex items-center gap-2"><Phone className="w-4 h-4" /> Phone</label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} className="input-field mt-1.5" />
        </div>
        <div>
          <label className="text-sm text-slate-300 font-medium inline-flex items-center gap-2"><Mail className="w-4 h-4" /> Email</label>
          <input value={user?.email ?? ''} disabled className="input-field mt-1.5 opacity-60" />
        </div>
        <button type="submit" disabled={saving} className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold py-3 rounded-xl inline-flex items-center justify-center gap-2">
          {saving ? <><span className="spinner" /> Saving…</> : saved ? <><Check className="w-4 h-4" /> Saved</> : <><Save className="w-4 h-4" /> Save changes</>}
        </button>
      </form>

      <button
        onClick={signOut}
        className="mt-5 w-full rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 font-semibold py-3.5 inline-flex items-center justify-center gap-2 hover:bg-rose-500/20"
      >
        <LogOut className="w-4 h-4" /> Sign out
      </button>
    </div>
  );
}
