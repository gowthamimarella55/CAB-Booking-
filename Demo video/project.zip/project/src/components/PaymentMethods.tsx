import { useEffect, useState } from 'react';
import { supabase, PaymentMethod } from '../lib/supabase';
import { CreditCard, Plus, Trash2, Check, Star } from 'lucide-react';

export default function PaymentMethods() {
  const [methods, setMethods] = useState<PaymentMethod[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [nickname, setNickname] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [brand, setBrand] = useState('Visa');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { load(); }, []);

  async function load() {
    const { data } = await supabase.from('payment_methods').select('*').order('created_at', { ascending: false });
    setMethods((data as PaymentMethod[]) ?? []);
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const digits = cardNumber.replace(/\s/g, '');
    if (digits.length < 12) { setError('Enter a valid card number.'); return; }
    const last4 = digits.slice(-4);
    if (methods && methods.length === 0) {
      await supabase.from('payment_methods').update({ is_default: false }).neq('id', '0');
    }
    const { error: insError } = await supabase.from('payment_methods').insert({
      nickname: nickname.trim() || `${brand} •••• ${last4}`,
      brand,
      last4,
      is_default: (methods?.length ?? 0) === 0,
    });
    if (insError) { setError(insError.message); return; }
    setNickname(''); setCardNumber(''); setShowForm(false);
    load();
  }

  async function setDefault(id: string) {
    await supabase.from('payment_methods').update({ is_default: false }).neq('id', id);
    await supabase.from('payment_methods').update({ is_default: true }).eq('id', id);
    load();
  }

  async function remove(id: string) {
    await supabase.from('payment_methods').delete().eq('id', id);
    load();
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 pb-10">
      <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Payment methods</h1>
      <p className="text-slate-400 mt-1">Saved cards used to pay for your rides automatically.</p>

      <div className="mt-6 space-y-3">
        {methods === null ? (
          <div className="text-slate-400 text-center py-12"><span className="spinner mx-auto mb-3" /></div>
        ) : methods.length === 0 && !showForm ? (
          <div className="text-center py-12 rounded-2xl bg-slate-900/60 border border-slate-800">
            <CreditCard className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-slate-300">No payment methods yet.</p>
            <button onClick={() => setShowForm(true)} className="mt-3 text-emerald-400 font-medium inline-flex items-center gap-1">
              <Plus className="w-4 h-4" /> Add a card
            </button>
          </div>
        ) : (
          methods.map((m) => (
            <div key={m.id} className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${m.brand === 'Visa' ? 'bg-sky-500/15 text-sky-300' : 'bg-orange-500/15 text-orange-300'}`}>
                <CreditCard className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-white truncate">{m.nickname}</div>
                <div className="text-sm text-slate-400">{m.brand} •••• {m.last4}</div>
              </div>
              {m.is_default && (
                <span className="text-xs bg-emerald-500/15 text-emerald-300 px-2.5 py-1 rounded-full inline-flex items-center gap-1">
                  <Star className="w-3 h-3" /> Default
                </span>
              )}
              {!m.is_default && (
                <button onClick={() => setDefault(m.id)} className="text-xs text-slate-400 hover:text-emerald-300 inline-flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Set default
                </button>
              )}
              <button onClick={() => remove(m.id)} className="text-slate-500 hover:text-rose-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}

        {showForm && (
          <form onSubmit={add} className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <div>
              <label className="text-sm text-slate-300 font-medium">Nickname</label>
              <input value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="Personal card" className="input-field mt-1.5" />
            </div>
            <div>
              <label className="text-sm text-slate-300 font-medium">Card number</label>
              <input
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                placeholder="4242 4242 4242 4242"
                className="input-field mt-1.5"
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="text-sm text-slate-300 font-medium">Brand</label>
              <select value={brand} onChange={(e) => setBrand(e.target.value)} className="input-field mt-1.5">
                <option>Visa</option>
                <option>Mastercard</option>
              </select>
            </div>
            {error && <p className="text-sm text-rose-400">{error}</p>}
            <div className="flex gap-2">
              <button type="submit" className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold py-3 rounded-xl">Save card</button>
              <button type="button" onClick={() => setShowForm(false)} className="px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl">Cancel</button>
            </div>
          </form>
        )}

        {methods && methods.length > 0 && !showForm && (
          <button onClick={() => setShowForm(true)} className="w-full py-3 rounded-2xl border border-dashed border-slate-700 text-slate-400 hover:text-emerald-300 hover:border-emerald-500 inline-flex items-center justify-center gap-2">
            <Plus className="w-4 h-4" /> Add another card
          </button>
        )}
      </div>
    </div>
  );
}
