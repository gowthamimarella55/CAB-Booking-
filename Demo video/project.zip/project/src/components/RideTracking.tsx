import { useEffect, useRef, useState } from 'react';
import { supabase, Booking } from '../lib/supabase';
import {
  MapPin, Navigation, Clock, Star, Phone, MessageSquare, Shield,
  CheckCircle2, X, Car,
} from 'lucide-react';

const STAGES: { key: Booking['status']; label: string; pct: number }[] = [
  { key: 'enroute', label: 'Driver en route to pickup', pct: 0 },
  { key: 'arrived', label: 'Driver arrived at pickup', pct: 33 },
  { key: 'inprogress', label: 'On the way to destination', pct: 66 },
  { key: 'completed', label: 'Trip completed', pct: 100 },
];

export default function RideTracking({ bookingId, onDone }: { bookingId: string; onDone: () => void }) {
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [stageIdx, setStageIdx] = useState(0);
  const [cancelled, setCancelled] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.from('bookings').select('*').eq('id', bookingId).maybeSingle().then(({ data }) => {
      if (!mounted || !data) return;
      setBooking(data as Booking);
      setStageIdx(0);
      setLoading(false);
    });
    return () => { mounted = false; };
  }, [bookingId]);

  useEffect(() => {
    if (!booking || cancelled) return;
    const totalSeconds = 24;
    let elapsed = 0;
    timer.current = window.setInterval(() => {
      elapsed += 0.5;
      const pct = Math.min(100, (elapsed / totalSeconds) * 100);
      setProgress(pct);
      const newStage = pct < 33 ? 0 : pct < 66 ? 1 : pct < 100 ? 2 : 3;
      if (newStage !== stageIdx) {
        setStageIdx(newStage);
        const status = STAGES[newStage].key;
        supabase.from('bookings').update({ status }).eq('id', booking.id).then(() => {
          if (status === 'completed') {
            supabase.from('bookings').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', booking.id);
          }
        });
      }
      if (pct >= 100 && timer.current) {
        clearInterval(timer.current);
      }
    }, 500);
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [booking, cancelled, stageIdx]);

  async function cancel() {
    if (!booking) return;
    setCancelled(true);
    if (timer.current) clearInterval(timer.current);
    await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', booking.id);
  }

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center text-slate-400">
        <span className="spinner mx-auto mb-4" />
        <p>Loading your ride…</p>
      </div>
    );
  }
  if (!booking) return null;

  const stage = STAGES[stageIdx];
  const done = progress >= 100 || cancelled;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 pb-12">
      <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900/60">
        <Map progress={progress} cancelled={cancelled} stage={stageIdx} />

        <div className="p-5 sm:p-6">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">
                {cancelled ? 'Ride cancelled' : done ? 'You arrived!' : stage.label}
              </div>
              <div className="text-slate-300 text-sm mt-0.5">
                {cancelled ? 'No charge applied.' : done ? 'Thanks for riding with Ucab.' : `ETA ${Math.max(1, Math.round((100 - progress) / 100 * (booking.eta_min ?? 5)))} min`}
              </div>
            </div>
            {!done && !cancelled && (
              <button onClick={cancel} className="text-sm text-rose-400 hover:text-rose-300 font-medium inline-flex items-center gap-1">
                <X className="w-4 h-4" /> Cancel ride
              </button>
            )}
          </div>

          <div className="mt-4 grid grid-cols-4 gap-1.5">
            {STAGES.map((s, i) => (
              <div key={s.key} className="flex flex-col items-center">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                  i <= stageIdx && !cancelled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500'
                }`}>
                  {i <= stageIdx && !cancelled ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 text-center hidden sm:block">{s.label.split(' ').slice(0, 2).join(' ')}</div>
              </div>
            ))}
          </div>

          <div className="mt-5 rounded-xl bg-slate-800/40 border border-slate-800 p-4 flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-slate-950 font-bold text-lg">
              {booking.driver_name?.split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-white truncate">{booking.driver_name}</div>
              <div className="text-sm text-slate-400 flex items-center gap-2">
                <span className="inline-flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /> {booking.driver_rating?.toFixed(1)}
                </span>
                <span className="text-slate-600">•</span>
                <span>{booking.vehicle_plate}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-200">
                <Phone className="w-4 h-4" />
              </button>
              <button className="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-200">
                <MessageSquare className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-4 grid sm:grid-cols-2 gap-3">
            <RouteCard icon={<div className="w-3 h-3 rounded-full bg-emerald-400" />} title="Pickup" text={booking.pickup} />
            <RouteCard icon={<MapPin className="w-3.5 h-3.5 text-rose-400" />} title="Drop-off" text={booking.dropoff} />
          </div>

          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <Metric icon={<Navigation className="w-4 h-4" />} label="Distance" value={`${Number(booking.distance_km).toFixed(1)} km`} />
            <Metric icon={<Clock className="w-4 h-4" />} label="Duration" value={`${booking.duration_min} min`} />
            <Metric icon={<Shield className="w-4 h-4" />} label="Fare" value={`$${booking.fare}`} />
          </div>

          {done && !cancelled && (
            <button
              onClick={onDone}
              className="mt-5 w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold py-3.5 rounded-xl"
            >
              Back to home
            </button>
          )}
          {cancelled && (
            <button
              onClick={onDone}
              className="mt-5 w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-3.5 rounded-xl"
            >
              Back to home
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Map({ progress, cancelled, stage }: { progress: number; cancelled: boolean; stage: number }) {
  const carX = 10 + (progress / 100) * 80;
  return (
    <div className="relative h-56 sm:h-64 bg-slate-950 overflow-hidden">
      <div className="absolute inset-0 opacity-40" style={{
        backgroundImage:
          'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }} />
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M 10 80 Q 30 30 50 50 T 90 20" stroke="rgba(16,185,129,0.25)" strokeWidth="2" fill="none" strokeDasharray="3 3" />
        <path
          d="M 10 80 Q 30 30 50 50 T 90 20"
          stroke={cancelled ? '#f43f5e' : '#10b981'}
          strokeWidth="2.5"
          fill="none"
          strokeDasharray="200"
          strokeDashoffset={cancelled ? 0 : 200 - (progress / 100) * 200}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute left-[10%] bottom-[18%] -translate-x-1/2 -translate-y-1/2">
        <div className="w-3 h-3 rounded-full bg-emerald-400 ring-4 ring-emerald-400/30" />
      </div>
      <div className="absolute right-[10%] top-[18%] translate-x-1/2 -translate-y-1/2">
        <MapPin className="w-5 h-5 text-rose-400 fill-rose-400/30" />
      </div>
      {!cancelled && (
        <div
          className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-500 ease-linear"
          style={{ left: `${carX}%`, top: `${80 - (progress / 100) * 60}%` }}
        >
          <div className="w-9 h-9 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/40">
            <Car className="w-5 h-5" />
          </div>
        </div>
      )}
      <div className="absolute top-3 left-3 text-xs bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-full text-slate-300 border border-slate-700">
        Live tracking • {stage < 2 ? 'to pickup' : 'to destination'}
      </div>
    </div>
  );
}

function RouteCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-xl bg-slate-800/40 border border-slate-800 p-3">
      <div className="text-xs text-slate-500 flex items-center gap-1.5">{icon} {title}</div>
      <div className="text-sm text-slate-200 mt-1 truncate">{text}</div>
    </div>
  );
}

function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-800/40 border border-slate-800 p-3">
      <div className="text-emerald-400 flex justify-center">{icon}</div>
      <div className="text-sm font-semibold text-white mt-1">{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}
