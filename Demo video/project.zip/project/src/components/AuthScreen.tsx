import { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { Car, Mail, Lock, User as UserIcon, Phone, ArrowRight } from 'lucide-react';

export default function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const res =
      mode === 'signin'
        ? await signIn(email.trim(), password)
        : await signUp(email.trim(), password, fullName.trim(), phone.trim());
    setBusy(false);
    if (res.error) setError(res.error);
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-950">
      <div className="relative hidden lg:flex lg:w-1/2 overflow-hidden bg-gradient-to-br from-emerald-600 via-teal-700 to-slate-900">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 0%, transparent 40%), radial-gradient(circle at 80% 70%, white 0%, transparent 40%)' }} />
        <div className="relative z-10 flex flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
              <Car className="w-6 h-6" />
            </div>
            <span className="text-2xl font-bold tracking-tight">Ucab</span>
          </div>
          <div>
            <h1 className="text-5xl font-bold leading-tight tracking-tight">
              Your ride,<br />right when<br />you need it.
            </h1>
            <p className="mt-6 text-lg text-emerald-50/80 max-w-md">
              Book a cab in seconds, track your driver in real time, and pay seamlessly. Travel simple, reliable, stress-free.
            </p>
            <div className="mt-10 grid grid-cols-3 gap-6">
              <Stat label="Avg arrival" value="3 min" />
              <Stat label="Cities" value="120+" />
              <Stat label="Riders" value="2.4M" />
            </div>
          </div>
          <p className="text-emerald-50/60 text-sm">Trusted by commuters worldwide.</p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
              <Car className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">Ucab</span>
          </div>

          <h2 className="text-3xl font-bold text-white tracking-tight">
            {mode === 'signin' ? 'Welcome back' : 'Create your account'}
          </h2>
          <p className="text-slate-400 mt-2">
            {mode === 'signin' ? 'Sign in to book your next ride.' : 'Join Ucab and start riding in minutes.'}
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            {mode === 'signup' && (
              <>
                <Field icon={<UserIcon className="w-5 h-5" />} label="Full name">
                  <input
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Sarah Williams"
                    className="input-field"
                  />
                </Field>
                <Field icon={<Phone className="w-5 h-5" />} label="Phone">
                  <input
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 555 010 2030"
                    className="input-field"
                  />
                </Field>
              </>
            )}
            <Field icon={<Mail className="w-5 h-5" />} label="Email">
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="input-field"
              />
            </Field>
            <Field icon={<Lock className="w-5 h-5" />} label="Password">
              <input
                required
                minLength={6}
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-field"
              />
            </Field>

            {error && (
              <div className="rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm px-4 py-3">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              {busy ? 'Please wait…' : (
                <>
                  {mode === 'signin' ? 'Sign in' : 'Create account'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-slate-400 mt-6 text-sm">
            {mode === 'signin' ? "Don't have an account?" : 'Already have an account?'}{' '}
            <button
              onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(null); }}
              className="text-emerald-400 font-semibold hover:text-emerald-300"
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm text-slate-300 font-medium">{label}</span>
      <div className="mt-1.5 relative">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">{icon}</div>
        {children}
      </div>
    </label>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-emerald-50/60 text-sm">{label}</div>
    </div>
  );
}
